package com.cybage.emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages="com.cybage")
public class SpringMvcEmplApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcEmplApplication.class, args);
	}

}
